package com.selenium.java;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class P19_DropDown {
  public static void main(String[] args) throws InterruptedException {
    WebDriver driver =new ChromeDriver();
    driver.manage().window().maximize();

    driver.navigate().to("https://www.shadi.com");
    Thread.sleep(3000);
   
    //1. identify drop down using locator
    WebElement dropdown=driver.findElement(By.id("ddlEducation")); 
    
    //2. create select class obj 
    //3. pass the dropdown ref to Select class cons.
    Select s= new Select(dropdown);
    
    /*4. use any one to select an option from drop down 
     * selectByIndex(); 
     * selectByValue();
     * selectByVisibleText();
    */ 
    s.selectByIndex(2);
    Thread.sleep(5000);
    
    s.selectByValue("6");
    Thread.sleep(3000);

    s.selectByVisibleText("Masters");

    Thread.sleep(3000);
    driver.close();
  }
}
