package com.selenium.java;

import java.time.Duration; 

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class P08_BrowserOperations {
  public static void main(String[] args) throws InterruptedException {
    ChromeDriver cdriver = new ChromeDriver();

    //maximize the window
    cdriver.manage().window().maximize();
    Thread.sleep(5000);
    
    //delete all cookies
    cdriver.manage().deleteAllCookies();
    
    //Resize the browser
    Dimension dim = cdriver.manage().window().getSize();
    System.out.println(dim.width + " " + dim.height);
    
    Dimension newDim = new Dimension(dim.width/2, dim.height/2);
    System.out.println(newDim.width + " " + newDim.height);
    
    cdriver.manage().window().setSize(newDim);

    Thread.sleep(3000);

    //Move the browser
    Point p = new Point(300, 200); 
    cdriver.manage().window().setPosition(p); 
    Thread.sleep(3000);

    //keep it open for 5s
    Thread.sleep(5000);

    //close the browser
    cdriver.close();
  }
}