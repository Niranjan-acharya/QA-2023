package com.selenium.java;

import org.testng.annotations.Test;

public class P44_TestNG_Suite {
  @Test
  public void positiveCredential1() {
    System.out.println("POSITIVE CREDENTIAL-1");
  }
  @Test
  public void positiveCredential2() {
    System.out.println("POSITIVE CREDENTIAL-2");
  }
}