package com.selenium.java;

import java.time.Duration; 
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P21_Popups {
  public static void main(String[] args) throws InterruptedException {
    WebDriver driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    
    driver.get("https://www.echoecho.com/javascript4.htm");
    Thread.sleep(3000);

    //1. Alert Box
    driver.findElement(By.name("B1")).click();

    Alert alert = driver.switchTo().alert();
    Thread.sleep(3000);

    alert.accept();
    Thread.sleep(3000);
    
    //2. Confirm Box
    driver.findElement(By.name("B2")).click();

    alert = driver.switchTo().alert();
    Thread.sleep(3000);

    alert.dismiss();
    Thread.sleep(3000);

    //3. Prompt Box
    driver.findElement(By.name("B3")).click();

    alert = driver.switchTo().alert();
    alert.sendKeys("NIRANJAN");
    Thread.sleep(3000);

    alert.accept();
    Thread.sleep(3000);

    driver.quit(); 
  }
}