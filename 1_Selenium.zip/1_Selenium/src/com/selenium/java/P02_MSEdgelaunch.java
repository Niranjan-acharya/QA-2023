package com.selenium.java;

import org.openqa.selenium.edge.EdgeDriver;

public class P02_MSEdgelaunch {
  public static void main(String[] args) {
    System.setProperty("webdriver.msedgedriver.driver", "E:\\selenium jar\\msedgedriver.exe");
    EdgeDriver edriver = new EdgeDriver();
  }
}