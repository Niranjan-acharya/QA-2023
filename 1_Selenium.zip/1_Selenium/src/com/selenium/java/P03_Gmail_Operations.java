package com.selenium.java;

import org.openqa.selenium.chrome.ChromeDriver;

public class P03_Gmail_Operations {
  public static void main(String[] args) throws InterruptedException {
    ChromeDriver cdriver = new ChromeDriver();

    cdriver.manage().window().maximize();

    //navigate to Gmail
    cdriver.get("https:\\www.gmail.com");

    String currentUrl = cdriver.getCurrentUrl();
    System.out.println("currentUrl :: "+currentUrl);

    String expectedtitle = "Gmail";
    String actualtitle = cdriver.getTitle();
    System.out.println("actualtitle :: "+actualtitle);

    if (expectedtitle.equalsIgnoreCase(actualtitle)) {
      System.out.println("Same");
    } else {
      System.out.println("Not Same");
    }

    // Gmail Page source 
    String pageSource = cdriver.getPageSource();
    System.out.println(pageSource);

    //keep it open for 5s
    Thread.sleep(5000);

    //close the browser
    cdriver.close();
  }
}
