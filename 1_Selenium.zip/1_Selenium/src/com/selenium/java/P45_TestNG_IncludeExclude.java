package com.selenium.java;

import org.testng.annotations.Test;

public class P45_TestNG_IncludeExclude {
  @Test
  public void test_1() {
    System.out.println("test1");
  }
  @Test
  public void test_2() {
    System.out.println("test2");
  }
  @Test
  public void test_3() {
    System.out.println("test3");
  }
}