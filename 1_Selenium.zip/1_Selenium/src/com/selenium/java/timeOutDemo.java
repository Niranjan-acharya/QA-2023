package com.selenium.java;

public class timeOutDemo {

}
