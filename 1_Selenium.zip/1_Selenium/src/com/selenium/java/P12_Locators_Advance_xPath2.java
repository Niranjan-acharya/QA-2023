package com.selenium.java;

import org.openqa.selenium.By;  
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P12_Locators_Advance_xPath2 {
  public static void main(String[] args) throws InterruptedException {
    ChromeDriver driver = new ChromeDriver();
    
    driver.manage().window().maximize();
    
    driver.get("E:\\Programs\\textbox2.html");
    
    WebElement p = driver.findElement(By.xpath("/html/body/div[1]/input[1]")); //Absolute path
    p.sendKeys("PPPP");

    WebElement q = driver.findElement(By.xpath("//input[2]")); //Relative path
    q.sendKeys("QQQQ");
    
    WebElement r = driver.findElement(By.xpath("//div[2]/input[1]")); //Relative path
    r.sendKeys("RRRR");
    
    WebElement s = driver.findElement(By.xpath("//div[2]/input[2]")); //Relative path
    s.sendKeys("SSSS");
    
    Thread.sleep(10000);
    driver.close();
  }
}
