package com.selenium.java;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P04_Quit_method {
  public static void main(String[] args) throws InterruptedException {
    WebDriver driver = new ChromeDriver();

    driver.manage().window().maximize();

    driver.get("E:\\Software Files\\eclipse-workspace\\06_selenium\\1_Selenium\\src\\HTML\\page1.html");
    Thread.sleep(5000);

    driver.findElement(By.linkText("Page 2")).click();
    Thread.sleep(5000);
//    driver.close(); //closes page1
    driver.quit(); //closes both page1 and page2
  }
}
