package com.selenium.java;

import java.time.Duration; 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class P17_Actions_MouseEvents {
  public static void main(String[] args) throws InterruptedException {
    WebDriver driver = new ChromeDriver();

    driver.manage().window().maximize();
    driver.get("https://www.amazon.in");

    Actions actions = new Actions(driver);

    WebElement acList = driver.findElement(By.xpath("//span[text()='Account & Lists']"));
    actions.moveToElement(acList).build().perform(); //build() compiles Action class code and perform() executes it

    WebElement yourAC = driver.findElement(By.xpath("//span[text()='Your Account']"));
    actions.moveToElement(yourAC).click().build().perform();
    //or
//    yourAC.click();

    //both in a single line
//    actions.moveToElement(acList).moveToElement(yourAC).click().build().perform();

    Thread.sleep(5000);
    driver.quit(); 
  }
}