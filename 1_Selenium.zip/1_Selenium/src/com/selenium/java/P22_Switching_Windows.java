package com.selenium.java;

import java.time.Duration; 
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class P22_Switching_Windows {
  public static void main(String[] args) throws InterruptedException {
    WebDriver driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

    driver.get("E:\\Software Files\\eclipse-workspace\\06_selenium\\1_Selenium\\src\\HTML\\page1.html");
    Thread.sleep(3000);
    String parentWindowID = driver.getWindowHandle();
    System.out.println("Parent Window ID:: "+parentWindowID);
    String mTitle=driver.getTitle();
    System.out.println("Parent Window Title:: "+mTitle);

    driver.findElement(By.linkText("Page 2")).click();
    Thread.sleep(3000); 

    Set<String> allWIndowsID = driver.getWindowHandles(); //which gives ID of each new window/Tab
    int count=allWIndowsID.size();
    System.out.println(count);

    for(String windID: allWIndowsID) {
      driver.switchTo().window(windID); //it is switching to Parent then Child
      System.out.println(driver.getTitle() +" :: "+windID);
    }

    driver.findElement(By.linkText("Page 3")).click();
    Thread.sleep(3000);
    driver.quit(); 
  }
}
