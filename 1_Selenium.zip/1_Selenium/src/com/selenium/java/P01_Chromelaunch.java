package com.selenium.java;

import org.openqa.selenium.chrome.ChromeDriver;

public class P01_Chromelaunch {
  public static void main(String[] args) throws InterruptedException {
//    String key = "webdriver.chromedriver.driver";
//    String value = "E:\\selenium jar\\chromedriver.exe";
//    System.setProperty(key, value);
//instead of above add chromedriver zip to libraries 
    ChromeDriver cdriver = new ChromeDriver();
  }
}
