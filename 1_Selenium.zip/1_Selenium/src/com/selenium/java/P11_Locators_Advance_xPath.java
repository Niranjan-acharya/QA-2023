package com.selenium.java;

import org.openqa.selenium.By;   
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P11_Locators_Advance_xPath {
  public static void main(String[] args) throws InterruptedException {
    ChromeDriver driver = new ChromeDriver();
    
    driver.manage().window().maximize();
    
    driver.get("E:\\Programs\\textbox.html");
    
    WebElement un = driver.findElement(By.xpath("/html/body/input[1]")); //Absolute path
    un.sendKeys("admin");

    WebElement pwd = driver.findElement(By.xpath("//input[2]")); //Relative path
    pwd.sendKeys("admin123");
    
    Thread.sleep(5000);
    driver.close();
  }
}
